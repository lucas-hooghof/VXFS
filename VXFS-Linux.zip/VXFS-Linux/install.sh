sudo install -m mkVXFS /usr/local/bin/mkVXFS
sudo install -m mkdirVXFS /usr/local/bin/mkdirVXFS
sudo install -m cpVXFS /usr/local/bin/cpVXFS